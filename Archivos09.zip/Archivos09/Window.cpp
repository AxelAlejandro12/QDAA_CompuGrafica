#include "Window.h"

Window::Window()
{
	width = 800;
	height = 600;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;
	muevex = 2.0f;
	muevex2 = 2.0f;
	articulacion1 = 0.0f;
	puertagiro = 0.0f;
	puertades = 0.0f;
	lucespuntuales = 0.0f;
	luzprendida = true;
	luzrico = true;
	cofreabierto = false;
	puertaabierta = false;
	puertaabierta2 = false;
	cocheAdelante = false;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
int Window::Initialise()
{
	//Inicializaci�n de GLFW
	if (!glfwInit())
	{
		printf("Fall� inicializar GLFW");
		glfwTerminate();
		return 1;
	}
	//Asignando variables de GLFW y propiedades de ventana
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//para solo usar el core profile de OpenGL y no tener retrocompatibilidad
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	//CREAR VENTANA
	mainWindow = glfwCreateWindow(width, height, "PracticaXX:Nombre de la practica", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo en crearse la ventana con GLFW");
		glfwTerminate();
		return 1;
	}
	//Obtener tama�o de Buffer
	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);

	//asignar el contexto
	glfwMakeContextCurrent(mainWindow);

	//MANEJAR TECLADO y MOUSE
	createCallbacks();


	//permitir nuevas extensiones
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("Fall� inicializaci�n de GLEW");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST); //HABILITAR BUFFER DE PROFUNDIDAD
							 // Asignar valores de la ventana y coordenadas
							 
							 //Asignar Viewport
	glViewport(0, 0, bufferWidth, bufferHeight);
	//Callback para detectar que se est� usando la ventana
	glfwSetWindowUserPointer(mainWindow, this);
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}
GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}




void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}
	if (key == GLFW_KEY_N)
	{
		if (theWindow->articulacion1 > -45)   // mientras no pase el l�mite negativo
		{
			theWindow->cofreabierto;
			theWindow->articulacion1 -= 10.0; // restar en lugar de sumar
		}
	}

	if (key == GLFW_KEY_M)
	{
		if (theWindow->articulacion1 < 0)    // mientras no pase el l�mite positivo
		{
			!theWindow->cofreabierto;
			theWindow->articulacion1 += 10.0; // sumar
		}
	}
	if (key == GLFW_KEY_Y)
	{
		theWindow->cocheAdelante = true;
		theWindow-> muevex += 1.0;
	}
	if (key == GLFW_KEY_U)
	{
		theWindow->cocheAdelante = false;
		theWindow-> muevex -= 1.0;
	}
	if (key == GLFW_KEY_R)
	{
		theWindow->muevex2 += 1.0;
	}
	if (key == GLFW_KEY_T)
	{
		theWindow->muevex2 -= 1.0;
	}
	if (key == GLFW_KEY_J)
	{
		theWindow-> lucespuntuales = 0.0;
	}
	if (key == GLFW_KEY_K)
	{
		theWindow->lucespuntuales = 1.0;
	}
	if (key == GLFW_KEY_P && action == GLFW_PRESS)
	{
		theWindow->luzprendida = !theWindow->luzprendida;
	}

	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
			//printf("se presiono la tecla %d'\n", key);
		}
		else if (action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
			//printf("se solto la tecla %d'\n", key);
		}
	}

	if (key == GLFW_KEY_X)
	{
		if (theWindow->puertagiro > -90)   // mientras no pase el l�mite negativo
		{
			theWindow->puertaabierta;
			theWindow->puertagiro -= 10.0; // restar en lugar de sumar
		}
		if (theWindow->puertades <= 0.5)
		{
			theWindow->puertaabierta2 = true;
			theWindow->puertades += 0.05;
		}
	}

	if (key == GLFW_KEY_Z)
	{
		if (theWindow->puertagiro < 0)   // mientras no pase el l�mite negativo
		{
			theWindow->puertaabierta;
			theWindow->puertagiro += 10.0; // restar en lugar de sumar
		}
		if (theWindow->puertades >= 0.05)
		{
			theWindow->puertaabierta2 = true;
			theWindow->puertades -= 0.05;
		}
	}

	//if (key == GLFW_KEY_L && action == GLFW_PRESS)
	//{
	//	extern bool luzAntorchaEncendida; // la variable global
	//	luzAntorchaEncendida = !luzAntorchaEncendida;
	//}

	if (key == GLFW_KEY_I && action == GLFW_PRESS)
	{
		theWindow->luzrico = !theWindow->luzrico;
	}

	if (key == GLFW_KEY_L && action == GLFW_PRESS)
	{
		theWindow->luzprendida = !theWindow->luzprendida;
	}


}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;

	theWindow->lastX = xPos;
	theWindow->lastY = yPos;
}


Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();

}
