#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	GLfloat getarticulacion1() { return articulacion1; }
	GLfloat getpuertagiro() { return puertagiro; }
	GLfloat getAuto() { return cocheAdelante; }
	GLfloat getmuevex() { return muevex; }
	GLfloat getpuertades() { return puertades; }
	GLfloat getmuevex2() { return muevex2; }
	GLfloat getprendida() { return luzprendida; }
	GLboolean getrico() { return luzrico; }
	GLboolean getLucespuntuales() { return lucespuntuales; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	
	~Window();
private: 
	GLFWwindow *mainWindow;
	GLint width, height;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	GLfloat articulacion1;
	GLfloat puertagiro;
	GLfloat puertades;
	GLfloat muevex;
	GLfloat muevex2;
	GLfloat luzprendida;
	GLboolean cofreabierto;
	GLboolean puertaabierta;
	GLboolean puertaabierta2;
	GLboolean cocheAdelante;
	GLboolean luzrico;
	GLboolean lucespuntuales;
	bool mouseFirstMoved;
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);

};

